/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#define Size 10

int hash(int key){
    return key%Size;
}

int probe(int H[] , int key){
    int index = hash(key);
    int i=0;
    while((H[(index+i)%Size])!=0){
        i++;
    }
    
    return (index+i)%Size;
}

void insert(int H[] , int key){
    int index = hash(key);
    
    if(H[index]!=0){
        index = probe(H , key);
    }
    H[index]= key;
}

int search(int H[] , int key){
    int index = hash(key);
    
    int i=0;
    while(H[(index+i)%Size]!=key){
        i++;
    }
    
    return (index+i)%Size;
}

int main()
{
    int HT[10] ={0};
    insert(HT , 10);
    insert(HT , 26);
    insert(HT , 67);
    insert(HT , 50);
    printf("%d " , search(HT , 67));
    return 0;
}
