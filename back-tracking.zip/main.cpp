/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

//Q.1 ou have n  tiles, where each tile has one letter tiles[i] printed on it.

//Return the number of possible non-empty sequences of letters you can make using the letters printed on those tiles
class Solution {
public:
    
    void solve(string tiles , string &output , set<string>&result , map<char , bool>& flag){
        for(int i=0 ; i<tiles.length(); i++){
            if(flag[i]==0){
                char ch = tiles[i];
                output.push_back(ch);
                flag[i] =1;
                result.insert(output);
                solve(tiles , output , result , flag);
                output.pop_back(); //back tracking
                flag[i] =0;
            }
        }
    }
    int numTilePossibilities(string tiles) {
        
        string output ="";
        set<string>result;
        
        map<char , bool>flag;
        solve(tiles , output , result , flag);
        
        return result.size();
    }
};

/* Q. 3 Given an array of distinct integers candidates and a target integer target, 
return a list of all unique combinations of
candidates where the chosen numbers sum to target. You may return the combinations in any order.
Input: candidates = [2,3,6,7], target = 7
Output: [[2,2,3],[7]]
Explanation:
2 and 3 are candidates, and 2 + 2 + 3 = 7. Note that 2 can be used multiple times.
7 is a candidate, and 7 = 7.
These are the only two combinations.*/

class Solution {
public:
    
    void solve(vector<int>& candidates, int target ,vector<vector<int>>&result ,vector<int>&output , int i){
        
        if(target==0){
            result.push_back(output);
            return;
        }
        
        if(target<0 ||i>=candidates.size()){
            return;
        }
        
        solve(candidates , target , result , output , i+1); //exclude ki call
        output.push_back(candidates[i]);
        solve(candidates , target-candidates[i] , result , output , i); //include ki call
        output.pop_back(); //back track
    }
    vector<vector<int>> combinationSum(vector<int>& candidates, int target) {
        
        vector<vector<int>>result ;
        vector<int>output ;
        int index =0;
        solve(candidates , target , result , output , index);
        
        return result;
    }
};

/*
q. 4 Given a collection of candidate numbers 
(candidates) and a target number (target), find all unique combinations 
in candidates where the candidate numbers sum to target.

Each number in candidates may only be used once in the combination.

Note: The solution set must not contain duplicate combinations.
Example 1:
Input: candidates = [10,1,2,7,6,1,5], target = 8
Output: 
[
[1,1,6],
[1,2,5],
[1,7],
[2,6]
]

Input: candidates = [2,5,2,1,2], target = 5
Output: 
[
[1,2,2],
[5]
]
*/
class Solution {
public:
    
    void solve(vector<int>& candidates, int target ,vector<vector<int>>&result ,vector<int>&output , int index){
        
        if(target==0){
            result.push_back(output);
            return;
        }
        
        if(target<0 ||index>=candidates.size()){
            return;
        }
        
        for(int i = index ; i<candidates.size() ; i++){
            if(i>index && candidates[i]==candidates[i-1]){
                continue;
            } // condition to avoid duplicate.
            if(candidates[i]>target){
                break;
            }
            output.push_back(candidates[i]);
            solve(candidates , target-candidates[i] , result , output , i+1); 
            output.pop_back(); 
        }
        
    }
    vector<vector<int>> combinationSum2(vector<int>& candidates, int target) {
        sort(candidates.begin() , candidates.end()); // because output in sorted order .
        vector<vector<int>>result ;
        vector<int>output ;
        int index =0;
        solve(candidates , target , result , output , index);
        
        return result;
    }
};

/*
q . 5 Find all valid combinations of k numbers that sum up to n such that the following conditions are true:

    Only numbers 1 through 9 are used.
    Each number is used at most once.

Return a list of all possible valid combinations. The list must not 
contain the same combination twice, and the combinations may be returned in 
any order.
Input: k = 3, n = 7
Output: [[1,2,4]]
Explanation:
1 + 2 + 4 = 7
There are no other valid combinations.
*/
class Solution {
public:
    
    void solve(int k, int n ,vector<vector<int>>&output , vector<int>&temp , int index){
        if(k==0 && n==0){
            output.push_back(temp);
            return;
        }
        
        
        for(int i=index ; i<10; i++ ){
            temp.push_back(i);
            solve(k-1 , n-i , output , temp ,i+1);
            temp.pop_back();
        }
    }
    vector<vector<int>> combinationSum3(int k, int n) {
        vector<vector<int>> output;
        
        vector<int>temp;
        int index =1;
        solve(k , n , output , temp ,index);
        
        return output;
    }
};

int main()
{
    cout<<"Hello World";

    return 0;
}

