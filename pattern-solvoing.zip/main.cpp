/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
int main() {
    // Write C++ code here
    int n =4;
    for(int i=1 ; i<=n ; i++){
        for(int j =1; j<=i-1 ; j++){
            cout<<" ";
        }
        for(int j =1; j<=n-i+1 ; j++){
            cout<<"*";
        }
        cout<<endl;
    }
    

    return 0;
}

/*
### full hollow pyramid
#include <iostream>
using namespace std;
int main() {
    int n=6;
    
    for(int i=1 ; i<=n ; i++){
        if(i==1){
            for(int j =1 ; j<=n-i; j++){
                cout<<"  ";
            }
            for(int j =1 ; j<=1; j++){
                cout<<"*";
            }
        }
        else if(i==n){
            for(int j =1 ; j<=n; j++){
                cout<<"*   ";
            }
        }
        else{
            for(int j =1 ; j<=n-i; j++){
                cout<<"  ";
            }
            for(int j =1 ; j<=1; j++){
                cout<<"*";
            }
            for(int j =1 ; j<=2*i-2; j++){
                cout<<"  ";
            }
            for(int j =1 ; j<=1; j++){
                cout<<"*";
            }
            
        }
        
        cout<<endl;
    }
  

    return 0;
}
*/
