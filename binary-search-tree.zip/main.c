/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

struct Node{
    struct Node* lchild;
    int data;
    struct Node* rchild;
}*root=NULL;

void insert(int key){
    struct Node* t = root , *r;
    if(root==NULL){
        struct Node* p = (struct Node*)malloc(sizeof(struct Node));
        p->rchild=p->lchild = NULL;
        p->data = key;
        root=p;
        return;
    }
    while(t){
        r=t;
        if(key<t->data){
            t=t->lchild;
        }
        else if(key>t->data){
            t=t->rchild;
        }
        else{
            return;
        }
        
    }
    struct Node* p = (struct Node*)malloc(sizeof(struct Node));
       
    p->data = key;
    if(p->data<r->data){
        r->lchild=p;
    }else{
        r->rchild =p;
    }
    
}

struct Node* search(int key){
    struct Node* t = root;
    while(t){
        if(t->data == key){
            return t;
        }
        else if(key<t->data){
            t=t->lchild;
        }else{
            t=t->rchild;
        }
    }
    return NULL;
}
void Inorder(struct Node* p){
    if(p){
        Inorder(p->lchild);
        printf("%d " , p->data);
        Inorder(p->rchild);
    }
}

int Height(struct Node* p){
    if(p==NULL){
        return 0;
    }
    int x , y;
    x = Height(p->lchild);
    y = Height(p->rchild);
    return x>y?x+1:y+1;
}

struct Node* Inpre(struct Node* p){
    while(p&&p->rchild!=NULL){
        p=p->rchild;
    }
    return p;
}
struct Node* Insucc(struct Node* p){
    while(p&&p->lchild!=NULL){
        p=p->lchild;
    }
    return p;
}

struct Node* Delete(struct Node* p , int key){
    struct Node* q;
    if(p==NULL){
        return NULL;
    }
    //leaf node 
    if(p->rchild ==NULL&& p->lchild==NULL){
        if(p==root){
            root =NULL;
        }
        free(p);
        return NULL;
    }
    
    if(key<p->data){
        p->lchild= Delete(p->lchild , key);
    }
    else if(key>p->data){
        p->rchild = Delete(p->rchild , key);
    }else{
        if(Height(p->rchild)>Height(p->lchild)){
            q=Insucc(p->rchild);
            p->data = q->data;
            p->rchild = Delete(p->rchild , key);
        }
        else{
            q=Inpre(p->lchild);
            p->data = q->data;
            p->lchild = Delete(p->lchild , key); //check for its child elements , if there than also shift them.
        }
    }
    return p;
}
int main()
{
    struct Node* temp;
    insert(9);
    insert(15);
    insert(5);
    insert(20);
    insert(16);
    insert(8);
    insert(12);
    insert(3);
    insert(6);
    Delete(root , 9);
    Inorder(root);
    printf("\n%d \n" , root->data);
    temp = search(15);
    if(temp){
        printf("\n%d found" , temp->data);
    }else{
        printf("\n sorry not found");
    }

    return 0;
}

