/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "Queue.h"
struct Node{
    struct Node* lchild;
    int data;
    struct Node* rchild;
}; 
struct Queue{
    int size;
    int front;
    int rear;
    Node **A;
};

void create(struct Queue* q, int size){
    q->size = size;
    q->front = q->rear =0;
    q->A = (Node **)malloc(q->size*sizeof(Node *));
}

void enqueue(struct Queue *Q , Node* x){
   
    if((Q->rear+1)%Q->size == Q->front){
        printf("Queue is Full");
    }else{
        Q->rear = (Q->rear+1)%Q->size;
        Q->A[Q->rear] =x;
        
    }
}

Node* dequeue(struct Queue *Q){
    Node* x=NULL;
    if(Q->front ==Q->rear){
        printf("Queue is Empty");
    }else{
        Q->front = (Q->front+1)%Q->size;
        x= Q->A[Q->front];
    }
    return x;
}

int isEmpty(struct Node q){
    return q.front==q.rear;
}
struct Node* root = NULL;

void crete_tree(){
    struct Node* p , *t;
    int x;
    struct Queue q;
    create(&q , 100);
    printf("Enter root value");
    scanf("%d" , &x);
    root = (struct Node*)malloc(sizeof(struct Node));
    root->data =x;
    root->lchild = root->rchild =NULL;
    enqueue(&q , root);
    while(!isEmpty(q)){
        p = dequeue(&q);
        printf("Enter left child of %d " , p->data);
        scanf("%d" , &x);
        if(x!=-1){
            t = (struct Node*)malloc(sizeof(struct Node));
            t->data =x;
            t->lchild=t->rchild=NULL;
            p->lchild=t;
            enqueue(&q , t);
        }
        printf("Enter right child of %d " , p->data);
        scanf("%d" , &x);
        if(x!=-1){
            t = (struct Node*)malloc(sizeof(struct Node));
            t->data =x;
            t->lchild=t->rchild=NULL;
            p->rchild=t;
            enqueue(&q , t);
        }
    }
}

void Inorder(struct Node *p){
    if(p){
        Inorder(p->lchild);
        printf("%d " , p->data);
        Inorder(p->rchild);
    }
}
int main()
{
    crete_tree();
    Inorder(root);

    return 0;
}
