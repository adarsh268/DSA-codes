/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
struct Stack{
    int size;
    int top;
    int *S;
};

void crete(struct Stack *st){
    printf("Enter the size of stack ") ;
    scanf("%d" , &st->size);
    st->S = (int *)malloc(st->size*sizeof(int));
    st->top =-1;
}
void display(struct Stack st){
    for(int i=st.top ; i>=0; i--){
        printf("%d ", st.S[i]);
    }
}

void push(struct Stack* st , int x){
    if(st->top == st->size-1){
        printf("Stack Overflow");
    }else{
        st->top++;
        st->S[st->top] = x;
    }
}

int pop(struct Stack *st){
    int x =-1;
    if(st->top==-1){
        printf("Stack Underflow\n");
    }else{
        x = st->S[st->top--];
    }
    return x;
}

int peek(struct Stack st , int pos){
    int x =-1;
    if(st.top-pos+1<0){
        printf("Invalid Index\n");
    }else{
        x = st.S[st.top-pos+1];
    }
    return x;
}

int isEmpty(struct Stack st){
    if(st.top==-1)return 1;
    return 0;
}

int isFull(struct Stack st){
    
    return st.top ==st.size-1;
}

int StackTop(struct Stack st){
    if(!isEmpty(st)){
        return st.S[st.top];
    }
    
    return -1;
}
int main()
{
    struct Stack st;
    crete(&st);
    push(&st , 10);
    push(&st , 0);
    push(&st , 108);
    printf("%d\n" ,StackTop(st));
    display(st);

    return 0;
}
