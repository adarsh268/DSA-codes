/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <vector>
#include <stack>
#include <algorithm> 
using namespace std;
    
    vector<long long> nextSmaller(long long arr[] , int n){
        vector<long long>ans;
        stack<long long>s;
        int j = n-1;
        while(j>=0){
            if(s.empty()){
                ans.push_back(n);
            }else{
                if(arr[s.top()]<arr[j]){
                    ans.push_back(s.top());
                }else{
                    while(!s.empty()&&arr[s.top()]>=arr[j]){
                        s.pop();
                    }
                    if(s.empty()){
                        ans.push_back(n);
                    }else{
                        ans.push_back(s.top());
                    }
                }
            }
            
            s.push(j);
            j--;
        }
        reverse(ans.begin(), ans.end());
        
        return ans;
    }
    vector<long long> prevSmaller(long long arr[] , int n){
        vector<long long>ans;
        stack<long long>s;
        int j = 0;
        while(j<n){
            if(s.empty()){
                ans.push_back(-1);
            }else{
                if(arr[s.top()]<arr[j]){
                    ans.push_back(s.top());
                }else{
                    while(!s.empty()&&arr[s.top()]>=arr[j]){
                        s.pop();
                    }
                    if(s.empty()){
                        ans.push_back(-1);
                    }else{
                        ans.push_back(s.top());
                    }
                }
            }
            
            s.push(j);
            j++;
        }
        return ans;
    }
    long long maxArea(long long arr[], int n){
        
        vector<long long> next = nextSmaller(arr , n);
        vector<long long> prev = prevSmaller(arr , n);
        
        long long maxi = -56;
        
        for(int i=0 ; i<n ; i++){
            long long length = arr[i];
            long long bredth = next[i]-prev[i]-1;
            long long int aaarea = length*bredth;
            maxi = max(maxi , aaarea);
        }
        return maxi;
    }
    
    //Function to find largest rectangular area possible in a given histogram.
    long long getMaxArea(long long arr[], int n)
    {
        // Your code here
        
        return maxArea(arr , n);
    }

int main()
{
    long long arr[5] ={10 , 2 , 7,8,5};
    long long next = getMaxArea(arr , 5);
    cout<<next;
    

    return 0;
}